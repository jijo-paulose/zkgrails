package org.zkoss.zkgrails.artefacts;

public interface GrailsCometClass {

}
