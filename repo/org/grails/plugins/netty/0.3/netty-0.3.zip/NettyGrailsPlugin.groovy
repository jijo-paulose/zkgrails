import th.ac.sut.gpsbus.*

class NettyGrailsPlugin {
    // the plugin version
    def version = "0.3"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.3 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    // TODO Fill in these fields
    def author = "Chanwit Kaewkasi"
    def authorEmail = "chanwit@gmail.com"
    def title = "Netty integration for Grails"
    def description = '''\\
Netty integration for Grails.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/netty"

    def doWithWebDescriptor = { xml ->
        // TODO Implement additions to web.xml (optional), this event occurs before 
    }

    def doWithSpring = {
        gpsBusServerHandler(GpsBusServerHandler.class) { bean ->
            bean.scope = "prototype"
            bean.autowire = "byName"
        }
        
        pipelineFactory(GpsBusPipelineFactory.class) { bean ->
            bean.scope = "prototype"
            gpsBusServerHandler = ref("gpsBusServerHandler")
        }
        myServer(Server.class) { bean ->
            bean.scope = "singleton"
            channelFactory = ref("org.jboss.netty.channel.socket.ServerSocketChannelFactory")            
            pipelineFactory = ref("pipelineFactory") 
            port = 6500
        }
    }

    def doWithDynamicMethods = { ctx ->
        // TODO Implement registering dynamic methods to classes (optional)
    }

    def doWithApplicationContext = { ctx ->
    }

    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }
}
