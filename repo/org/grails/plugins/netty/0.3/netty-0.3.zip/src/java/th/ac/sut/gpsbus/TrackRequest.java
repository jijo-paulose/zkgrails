package th.ac.sut.gpsbus;

public class TrackRequest extends Request {

    final public String[] data;
    
    public TrackRequest(byte[] id, int command, byte[] data) throws Exception {
        super(id, command);
        this.data = new String(data, "ASCII").split("\\|");
    }

}