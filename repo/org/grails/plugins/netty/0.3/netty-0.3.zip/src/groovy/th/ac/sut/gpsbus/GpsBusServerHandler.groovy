package th.ac.sut.gpsbus

import java.util.concurrent.atomic.AtomicLong
import java.util.logging.Level
import java.util.logging.Logger

import org.jboss.netty.buffer.ChannelBuffer
import org.jboss.netty.channel.ChannelHandlerContext
import org.jboss.netty.channel.ExceptionEvent
import org.jboss.netty.channel.MessageEvent
import org.jboss.netty.channel.SimpleChannelUpstreamHandler

class GpsBusServerHandler extends SimpleChannelUpstreamHandler {

    def gpsService

    private final AtomicLong transferredBytes = new AtomicLong()
    public long getTransferredBytes() {
      return transferredBytes.get()
    }

    @Override
    public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) {
      def r = e.message
      switch(r) {
          case TrackRequest.class: 
            gpsService.update(r);
            break;
          case LoginRequest.class: 
            break;
      }      
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) {
      e.getChannel().close()
    }
}
