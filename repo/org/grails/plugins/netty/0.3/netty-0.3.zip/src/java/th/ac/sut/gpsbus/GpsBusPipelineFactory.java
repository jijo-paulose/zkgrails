package th.ac.sut.gpsbus;

import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.handler.codec.frame.DelimiterBasedFrameDecoder;
import org.jboss.netty.handler.codec.frame.Delimiters;
import org.jboss.netty.handler.codec.string.StringDecoder;
import org.jboss.netty.handler.codec.string.StringEncoder;

public class GpsBusPipelineFactory implements ChannelPipelineFactory {
    
    private GpsBusServerHandler gpsBusServerHandler;
    
    public GpsBusServerHandler getGpsBusServerHandler() {
        return this.gpsBusServerHandler;
    }
    
    public void setGpsBusServerHandler(GpsBusServerHandler value) {
        this.gpsBusServerHandler = value;
    }
        
    public ChannelPipeline getPipeline() throws Exception {    
        ChannelPipeline pipeline = Channels.pipeline();
        pipeline.addLast("frameDecoder", new DelimiterBasedFrameDecoder(8192, Delimiters.lineDelimiter()));
        pipeline.addLast("decoder", new VT310Decoder());
        pipeline.addLast("encoder", new StringEncoder());        
        pipeline.addLast("handler", this.gpsBusServerHandler);
        return pipeline;
    }

}


