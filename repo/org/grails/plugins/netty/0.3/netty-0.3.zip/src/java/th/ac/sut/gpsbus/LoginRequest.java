package th.ac.sut.gpsbus;

public class LoginRequest extends Request {

    public LoginRequest(byte[] id, int command) throws Exception {
        super(id, command);
    }

}