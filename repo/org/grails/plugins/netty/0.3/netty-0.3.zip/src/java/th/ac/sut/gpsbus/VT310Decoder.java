package th.ac.sut.gpsbus;

import org.jboss.netty.channel.*;
import org.jboss.netty.buffer.*;
import org.jboss.netty.handler.codec.frame.FrameDecoder;
import org.jboss.netty.handler.codec.frame.CorruptedFrameException;

public class VT310Decoder extends FrameDecoder {

    private Object decodeTrack(byte[] id,
                               int command,
                               int frameLength,
                               ChannelBuffer buffer) throws Exception {
        int dataLength = frameLength
                         - 2 // $$
                         - 2 // size of frame length
                         - 7 // id length
                         - 2 // command
                         - 2 // crc
                         - 2 // ending
                        ;
        //System.out.println("Calculated Data Length " + dataLength);
        byte[] data = new byte[dataLength];
        buffer.readBytes(data);
        //System.out.println("Read data");
        return new TrackRequest(
            id,
            command,
            data
        );
    }

    private Object decodeLogin(byte[] id,
                               int command,
                               int frameLength,
                               ChannelBuffer buffer) throws Exception {
        return new LoginRequest(id, command);
    }

    @Override
    protected Object decode(ChannelHandlerContext ctx,
                            Channel channel,
                            ChannelBuffer buffer) throws Exception {
        // Wait until the length prefix is available.
        if (buffer.readableBytes() < 5) {
            return null;
        }

        buffer.markReaderIndex();
        // Check the magic number.
        int magic1 = buffer.readUnsignedByte();
        if (magic1 != '$') {
            buffer.resetReaderIndex();
            throw new CorruptedFrameException("Invalid magic number: " + magic1);
        }
        //System.out.println("Found $");
        //System.out.println("Readable bytes is <" + buffer.readableBytes() + ">");
        int magic2 = buffer.readUnsignedByte();
        if (magic2 != '$') {
            buffer.resetReaderIndex();
            throw new CorruptedFrameException("Invalid magic number: " + magic2);
        }
        //System.out.println("Found $$");
        //System.out.println("Readable bytes is <" + buffer.readableBytes() + ">");

        // Wait until the whole data is available.
        // 2 bytes data length
        int frameLength = buffer.readUnsignedShort();
        //System.out.println("Checking frame length: <" + frameLength + ">");
        //System.out.println("Readable bytes is <" + buffer.readableBytes() + ">");
        if (buffer.readableBytes() < frameLength - 6) {
            buffer.resetReaderIndex();
            return null;
        }
        //System.out.println("Found $$<" + frameLength + ">");

        // 7 bytes ID
        byte[] id = new byte[7];
        buffer.readBytes(id);
        //System.out.println("Found ID");

        // 2 bytes command
        int command = buffer.readUnsignedShort();
        System.out.println("Found COMMAND: " + Integer.toHexString(command));

        Object result = null;
        switch(command) {
            case 0x9955: result = decodeTrack(id, command, frameLength, buffer); break;
            case 0x5000: result = decodeLogin(id, command, frameLength, buffer); break;
            default: throw new RuntimeException("NYI");
        }

        int crc = buffer.readUnsignedShort(); // discard CRC
        // int eol = buffer.readUnsignedShort(); // discard \r\n
        // System.out.println("Found CRC and EOL");
        return result;
    }
}