package th.ac.sut.gpsbus

import org.jboss.netty.channel.*
import org.jboss.netty.bootstrap.ServerBootstrap
import java.net.*

class Server {

    def channelFactory
    def pipelineFactory
    def port

    private Channel server

    void start() {
        def bootstrap = new ServerBootstrap(channelFactory)
        bootstrap.setPipelineFactory(this.pipelineFactory);
        // bootstrap.setOption("child.tcpNoDelay", true);
        // bootstrap.setOption("child.keepAlive", true);

        // bind and start to accept incoming connections
        this.server = bootstrap.bind(new InetSocketAddress(port))
        println "GPS Server running. Connect to tcp://localhost:$port"
    }
}