package th.ac.sut.gpsbus;

public class Request {

    final public String id;
    final public int command;

    public Request(byte[] id, int command) throws Exception {
        this.id = bytesToString(id);
        // new String(id, "ASCII");
        this.command = command;
    }
    
    private String bytesToString(byte[] bytes) {
        String s = "";
        for(byte b: bytes) {            
            if(b != -1) {
                String h = Integer.toHexString( b );
                if( h.length() == 1 ) h = "0" + h; 
                s += h;
            }
        }
        return s;
    }
    
}