@artifact.package@import org.zkoss.zk.grails.*

class @artifact.name@ extends GrailsComposer {

    def afterCompose = { window ->
        // initialize components here
    }
}
