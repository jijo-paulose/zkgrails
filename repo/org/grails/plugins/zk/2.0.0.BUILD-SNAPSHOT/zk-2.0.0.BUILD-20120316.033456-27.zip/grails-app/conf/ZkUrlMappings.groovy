class ZkUrlMappings {

    static excludes = ['/zkau/*']

    static mappings = {
        "/"(view:"/index.zul")
    }

}
