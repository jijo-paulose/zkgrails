package org.zkoss.zk.grails.dev;

import java.util.ArrayList;
import java.util.List;

public class DevHolder {

	private List<String> list = new ArrayList<String>();

	public boolean check(String s) {
		if(list.contains(s)) {
			list.remove(s);
			return true;
		}
		return false;
	}

	public void add(String s) {
		list.add(s);
	}

}
