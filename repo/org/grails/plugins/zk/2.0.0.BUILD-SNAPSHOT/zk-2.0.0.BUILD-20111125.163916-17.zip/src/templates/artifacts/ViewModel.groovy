@artifact.package@import org.zkoss.zk.grails.*

class @artifact.name@ extends GrailsViewModel {

    static binding = {        
    }

}
