package org.zkoss.zk.grails.artefacts;

public interface GrailsCometClass {

}
