modules = {

    def pluginName = 'kendoUi'

    'kendo-theme' {
        resource id:'kendo-common-theme',
            url:  [plugin: pluginName, dir: 'kendo-ui/styles', file:'kendo.common.min.css'],
            attrs:[media:'screen, projection']
        resource id:'kendo-theme',
            url:  [plugin: pluginName, dir: 'kendo-ui/styles', file:'kendo.default.min.css'],
            attrs:[media:'screen, projection']
    }

    'kendo-ui' {
        dependsOn 'jquery', 'kendo-theme'
        resource id:'kendo-ui',
            url:  [plugin: pluginName, dir:'kendo-ui/js', file:'kendo.all.min.js'],
            nominify: true, disposition: 'head'
    }

    'kendo-mobile-theme' {
        resource id:'kendo-mobile-theme',
            url: [plugin: pluginName, dir: 'kendo-ui/styles', file:'kendo.mobile.all.min.css'],
            attrs:[media:'screen, projection']
    }

    'kendo-mobile' {
        dependsOn 'kendo-ui', 'kendo-mobile-theme'
        resource id:'kendo-mobile',
            url: [plugin: pluginName, dir:'kendo-ui/js', file:'kendo.mobile.min.js'],
            nominify: true, disposition: 'head'
    }

}