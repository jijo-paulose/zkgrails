package kendo.ui

class KendoUiTagLib {

    static namespace = "k"    

    def viewModel = { attrs ->
        out << "<script>"
        out << "</script>"
    }

    /**
     * Tag auto complete for Kendo-UI
     *
     * @params attrs Attributes of the tag.
    **/
    def autocomplete = { attrs ->
        def id = attrs['id']
        def controller = attrs.remove('controller')
        def action = attrs.remove('action')
        def link = g.createLink(action: action, controller: controller)

        def minLength = attrs.remove('min-length')
        def dataTextField = attrs.remove('data-text-field')
        def prefix = "param-"
        def dataParams = attrs?.collectEntries { key, v ->
            if(key?.startsWith(prefix)) {
                return [(key-prefix): v]
            } else {
                return [:]
            }
        }
        attrs = attrs.collectEntries { k, v -> if(!k.startsWith(prefix)) [(k):v] else [:] }
        out << '<input ' + attrs.collect {k, v -> "$k=\"$v\""}.join(' ') + '/>\n'
        out << '<script>\n' +
        '$(document).ready(function(){\n' +
        '    $("#' + id + '").kendoAutoComplete({\n';
        if(minLength) {
            out << "        minLength:${minLength},\n"
        }
        if(dataTextField) {
            out << "        dataTextField: \"${dataTextField}\",\n"
        }
        def dataParamBlock = dataParams.collect { key, v ->
            if(v.contains('self')) {
                def self = '$("#' + id + '").data("kendoAutoComplete")'
                return "${key}: function(){var self=${self}; return ${v};}"
            } else {
                return "${key}: function(){return \"${v}\";}"
            }
        }.join(',\n                        ')
        out << '' +
        '        dataSource: new kendo.data.DataSource({\n' + 
        '            transport: {\n' +
        '                read: {\n'  +
        '                    url: "' + link + '",\n' +
        '                    data: {\n' +
        '                        ' + dataParamBlock + '\n' +
        '                    }\n' +
        '                }\n'+
        '            }\n'+
        '        }),\n'+
        '        change: function(){\n'+
        '            this.dataSource.read();\n'+
        '        }\n'+
        '    })\n'+
        '});\n'+
        '</script>'
    }

    def calendar = { attrs ->
        def id = attrs['id']
        out << '<div ' + attrs.collect {k, v -> "$k=\"$v\""}.join(' ') + '/>\n'
        out << '<script>\n' +
        '$(document).ready(function(){\n' +
        '    $("#' + id + '").kendoCalendar();\n' +
        '});\n' +
        '</script>'
    }

    def combobox = { attrs ->
   
    }
}
