class KendoUiGrailsPlugin {

    def version = "1.0.1.BUILD-SNAPSHOT"

    def grailsVersion = "2.0 > *"

    def pluginExcludes = [
        "grails-app/views/error.gsp"
    ]

    def title = "Kendo UI plugin"
    def author = "Chanwit Kaewkasi"
    def authorEmail = "chanwit@gmail.com"
    def description = '''\
A Grails plugin to supply Kendo UI (kendoui.web-dataviz.2011.3.1129.open-source) dependencies.
This plugin also supplies KnockoutJS 2.0.0 to support the ViewModel pattern (Will be dropped when Kendo-UI supports ViewModel natively).
'''

    def license = "GPL3"

    def documentation = "http://grails.org/plugin/kendo-ui"

}
